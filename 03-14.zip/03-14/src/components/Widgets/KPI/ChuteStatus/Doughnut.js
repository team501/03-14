import React, {Component} from 'react';
import {Doughnut} from 'react-chartjs-2';

class DoughnutChart extends Component {
	constructor(props) {
		super(props);
		this.state = { isLoading:false };
	}	
	
	data = {  labels: this.props.label,
		 	  datasets: [{ data: [this.props.data.chuteFull, this.props.data.empty,
		 		  				  this.props.data.error, this.props.data.disabled],
		 		  		   backgroundColor: this.props.color,
		 		  		   hoverBackgroundColor: this.props.color
	 					}]
			};
	
	render () {
		if(this.state.isLoading) {
			return(<div></div>);
		} else {
			return( <Doughnut data={this.data} height={250} width={300} options={ { maintainAspectRatio: false,
											   									  	responsive: false,
											   									  	legend: { display: false }
											   									} } /> );
			}
	}
}

export default DoughnutChart;