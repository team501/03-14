import React, { Component } from 'react';



class NumberClass extends Component {



	format_number(currency, typ, num){

		return ( new Intl.NumberFormat(typ, { style: 'currency',

			currency: currency,

			maximumSignificantDigits: 4,

		}).format(num).replace("€", "").replace("$", "").replace("£", "").trim()



		);

	}



	data = localStorage.getItem("currencyType", "EUR@de-DE").split('@')

	render() { return ( <React.Fragment>

	{this.format_number(this.data[0], this.data[1], this.props.number)}

	</React.Fragment>         

	);

	}

}

export default NumberClass;