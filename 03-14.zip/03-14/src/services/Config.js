export const baseURL = "http://localhost:9080/";
export const graphQlURLPrd = "http://localhost:8088/graphql";
export const wCSURL = "http://localhost:8082/api/login";
